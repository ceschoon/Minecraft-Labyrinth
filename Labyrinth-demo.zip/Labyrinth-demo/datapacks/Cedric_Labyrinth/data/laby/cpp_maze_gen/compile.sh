#! /bin/bash

g++ -o generate_maze generate_maze.cpp Map.cpp
g++ -o mcfunction_maze mcfunction_maze.cpp
g++ -o mcfunction_build mcfunction_build.cpp

